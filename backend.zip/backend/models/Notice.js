const mongoose = require("mongoose");

const noticeSchema = new mongoose.Schema(
    {
        title: { type: String, required: true, trim: true },
        content: { type: String, required: true },
        summary: { type: String },
        targetAudience: {
            type: String,
            enum: ["All", "Students", "Faculty"],
            default: "All"
        },
        postedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }
    },
    { timestamps: true }
);

module.exports = mongoose.model("Notice", noticeSchema);
